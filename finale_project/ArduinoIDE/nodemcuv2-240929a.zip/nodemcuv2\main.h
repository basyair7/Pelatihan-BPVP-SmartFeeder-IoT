/*! @file main.h
 *  @version 1.0.0
*/

#pragma once

#include <Arduino.h>
#include "ProgramWiFi.h"

extern ProgramWiFi programWiFi;
extern void __setup__();
extern void __loop__();