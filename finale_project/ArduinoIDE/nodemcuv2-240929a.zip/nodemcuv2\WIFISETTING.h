#define SSID_STA		  "@Wifi.com 23"
#define PASSWORD_STA	"Hostpot_ahul7"
#define SSID_AP			  "SmartFeeder V1"
#define PASSWORD_AP		"Admin#1234"
